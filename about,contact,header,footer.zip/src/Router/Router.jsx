import React from 'react'
import { RootLayout } from '../Layout/RootLayout'
import { AboutPage } from '../Pages/AboutPage'
import { ContactPage } from '../Pages/ContactPage'
import { createBrowserRouter } from 'react-router-dom'

export const router=createBrowserRouter([
 {
        path: "/",
        element:<RootLayout/>,
        children:[
          
  {
                path: "About",
                element: <AboutPage/>
            },
 {
                path: "contact",
                element: <ContactPage/>
            },
           
        ]},

    

])
